A Pen created at CodePen.io. You can find this one at http://codepen.io/ariona/pen/KrRogZ.

 This is the simple Synchronised carousel between carousel on the back and a carousel within the macbook screen.

The library used here is the awesome slick carousel http://kenwheeler.github.io/slick/ , You should check it out :)

CSS3 filter is used to blur the underlaying carousel.

Image Credit:
- All project images by http://unsplash.it
- Macbook Mockup by http://facebook.design